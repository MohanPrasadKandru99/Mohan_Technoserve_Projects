package com.cg.placementmanagement.exceptions;

@SuppressWarnings("serial")
public class StudentNotFoundException extends Exception {

}
