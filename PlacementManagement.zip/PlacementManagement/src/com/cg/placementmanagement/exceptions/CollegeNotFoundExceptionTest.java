package com.cg.placementmanagement.exceptions;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

@SuppressWarnings("unused")
public class CollegeNotFoundExceptionTest {

	@Test
	void testException() {
		fail("Not yet implemented");
	}

	@Test
	void testExceptionString() {
		fail("Not yet implemented");
	}

	@Test
	void testExceptionStringThrowable() {
		fail("Not yet implemented");
	}

	@Test
	void testExceptionThrowable() {
		fail("Not yet implemented");
	}

	@Test
	void testExceptionStringThrowableBooleanBoolean() {
		fail("Not yet implemented");
	}

	@Test
	void testToString() {
		fail("Not yet implemented");
	}

	@Test
	void testThrowable() {
		fail("Not yet implemented");
	}

	@Test
	void testThrowableString() {
		fail("Not yet implemented");
	}

	@Test
	void testThrowableStringThrowable() {
		fail("Not yet implemented");
	}

	@Test
	void testThrowableThrowable() {
		fail("Not yet implemented");
	}

	@Test
	void testThrowableStringThrowableBooleanBoolean() {
		fail("Not yet implemented");
	}

	@Test
	void testGetMessage() {
		fail("Not yet implemented");
	}

	@Test
	void testGetLocalizedMessage() {
		fail("Not yet implemented");
	}

	@Test
	void testGetCause() {
		fail("Not yet implemented");
	}

	@Test
	void testInitCause() {
		fail("Not yet implemented");
	}

	@Test
	void testSetCause() {
		fail("Not yet implemented");
	}

	@Test
	void testPrintStackTrace() {
		fail("Not yet implemented");
	}

	@Test
	void testPrintStackTracePrintStream() {
		fail("Not yet implemented");
	}

	@Test
	void testPrintStackTracePrintWriter() {
		fail("Not yet implemented");
	}

	@Test
	void testFillInStackTrace() {
		fail("Not yet implemented");
	}

	@Test
	void testGetStackTrace() {
		fail("Not yet implemented");
	}

	@Test
	void testSetStackTrace() {
		fail("Not yet implemented");
	}

	@Test
	void testAddSuppressed() {
		fail("Not yet implemented");
	}

	@Test
	void testGetSuppressed() {
		fail("Not yet implemented");
	}

	@Test
	void testObject() {
		fail("Not yet implemented");
	}

	@Test
	void testGetClass() {
		fail("Not yet implemented");
	}

	@Test
	void testHashCode() {
		fail("Not yet implemented");
	}

	@Test
	void testEquals() {
		fail("Not yet implemented");
	}

	@Test
	void testClone() {
		fail("Not yet implemented");
	}

	@Test
	void testNotify() {
		fail("Not yet implemented");
	}

	@Test
	void testNotifyAll() {
		fail("Not yet implemented");
	}

	@Test
	void testWait() {
		fail("Not yet implemented");
	}

	@Test
	void testWaitLong() {
		fail("Not yet implemented");
	}

	@Test
	void testWaitLongInt() {
		fail("Not yet implemented");
	}

	@Test
	void testFinalize() {
		fail("Not yet implemented");
	}

}
