package com.cg.placementmanagement.exceptions;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class InvalidHallTicketExceptionTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
