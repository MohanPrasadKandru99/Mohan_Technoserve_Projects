package com.cg.placementmanagement.exceptions;

@SuppressWarnings("serial")
public class InvalidUserNameOrPasswordException extends Exception {

}
