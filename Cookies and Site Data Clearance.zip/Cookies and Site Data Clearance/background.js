chrome.browserAction.onClicked.addListener(function (tab) {
    showConfirmationDialog(tab);
});

chrome.commands.onCommand.addListener(function (command) {
    if (command === "reload_cache") {
        getCurrentTab(function (tab) {
            showConfirmationDialog(tab);
        });
    }
});

function showConfirmationDialog(tab) {
    if (confirm("Are you sure you want to empty the cache and hard reload this page?")) {
        reloadPage(tab.id);
    }
}

function reloadPage(tabId) {
    chrome.tabs.reload(tabId, { bypassCache: true }, function () {
        notifyUser("Cache cleared and page reloaded successfully.");
    });
}

function getCurrentTab(callback) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs.length > 0) {
            callback(tabs[0]);
        }
    });
}

function notifyUser(message) {
    chrome.notifications.create({
        type: "basic",
        iconUrl: "icon.png",
        title: "Cache Reloader",
        message: message
    });
}
